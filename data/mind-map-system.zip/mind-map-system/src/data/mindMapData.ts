export interface MindMapNodeData {
  id: string;
  name: string;
  type: 'root' | 'folder' | 'skill' | 'plugin' | 'file' | 'agent' | 'tool' | 'reference';
  color?: string;
  description?: string;
  children?: MindMapNodeData[];
}

export const mindMapData: MindMapNodeData = {
  id: 'root',
  name: 'MiniMax System',
  type: 'root',
  description: 'מערכת MiniMax - סקילים, סוכנים ופלאגאינים',
  children: [
    {
      id: 'skills',
      name: 'Skills',
      type: 'folder',
      color: '#3B82F6',
      description: 'כל הסקילים של המערכת',
      children: [
        {
          id: 'minimax-docx',
          name: 'minimax-docx',
          type: 'skill',
          color: '#3B82F6',
          description: 'יצירה ועריכת מסמכי Word בפורמט OpenXML',
          children: [
            {
              id: 'docx-references',
              name: 'References',
              type: 'folder',
              color: '#8B5CF6',
              children: [
                {
                  id: 'docx-ref-cjk-typography',
                  name: 'cjk_typography.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-cjk-university',
                  name: 'cjk_university_template_guide.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-comments',
                  name: 'comments_guide.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-design-good-bad',
                  name: 'design_good_bad_examples.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-design-principles',
                  name: 'design_principles.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-openxml-order',
                  name: 'openxml_element_order.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-openxml-enc1',
                  name: 'openxml_encyclopedia_part1.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-openxml-enc2',
                  name: 'openxml_encyclopedia_part2.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-openxml-enc3',
                  name: 'openxml_encyclopedia_part3.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-namespaces',
                  name: 'openxml_namespaces.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-units',
                  name: 'openxml_units.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-scenario-a',
                  name: 'scenario_a_create.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-scenario-b',
                  name: 'scenario_b_edit_content.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-scenario-c',
                  name: 'scenario_c_apply_template.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-track-changes',
                  name: 'track_changes_guide.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-troubleshooting',
                  name: 'troubleshooting.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-typography',
                  name: 'typography_guide.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'docx-ref-xsd',
                  name: 'xsd_validation_guide.md',
                  type: 'reference',
                  color: '#F59E0B'
                }
              ]
            },
            {
              id: 'docx-scripts',
              name: 'Scripts',
              type: 'folder',
              color: '#8B5CF6',
              children: [
                {
                  id: 'docx-scripts-dotnet',
                  name: 'dotnet',
                  type: 'folder',
                  color: '#8B5CF6',
                  children: [
                    {
                      id: 'docx-cli',
                      name: 'MiniMaxAIDocx.Cli',
                      type: 'tool',
                      color: '#06B6D4'
                    },
                    {
                      id: 'docx-core',
                      name: 'MiniMaxAIDocx.Core',
                      type: 'tool',
                      color: '#06B6D4',
                      children: [
                        {
                          id: 'docx-commands',
                          name: 'Commands',
                          type: 'folder',
                          color: '#8B5CF6'
                        },
                        {
                          id: 'docx-openxml',
                          name: 'OpenXml',
                          type: 'folder',
                          color: '#8B5CF6'
                        },
                        {
                          id: 'docx-samples',
                          name: 'Samples',
                          type: 'folder',
                          color: '#8B5CF6'
                        },
                        {
                          id: 'docx-typography',
                          name: 'Typography',
                          type: 'folder',
                          color: '#8B5CF6'
                        },
                        {
                          id: 'docx-validation',
                          name: 'Validation',
                          type: 'folder',
                          color: '#8B5CF6'
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          ]
        },
        {
          id: 'minimax-pdf',
          name: 'minimax-pdf',
          type: 'skill',
          color: '#8B5CF6',
          description: 'יצירת PDF עם מערכת עיצוב מתקדמת',
          children: [
            {
              id: 'pdf-design',
              name: 'design',
              type: 'folder',
              color: '#8B5CF6',
              children: [
                {
                  id: 'pdf-design-design',
                  name: 'design.md',
                  type: 'reference',
                  color: '#F59E0B'
                }
              ]
            },
            {
              id: 'pdf-scripts',
              name: 'scripts',
              type: 'folder',
              color: '#8B5CF6'
            }
          ]
        },
        {
          id: 'minimax-xlsx',
          name: 'minimax-xlsx',
          type: 'skill',
          color: '#10B981',
          description: 'מערכת יצירת גיליונות עבודה מתקדמת',
          children: [
            {
              id: 'xlsx-scripts',
              name: 'Scripts',
              type: 'folder',
              color: '#8B5CF6'
            },
            {
              id: 'xlsx-charts',
              name: 'charts.md',
              type: 'reference',
              color: '#F59E0B'
            },
            {
              id: 'xlsx-pivot',
              name: 'pivot.md',
              type: 'reference',
              color: '#F59E0B'
            },
            {
              id: 'xlsx-styling',
              name: 'styling.md',
              type: 'reference',
              color: '#F59E0B'
            }
          ]
        },
        {
          id: 'pptx-generator',
          name: 'pptx-generator',
          type: 'skill',
          color: '#F59E0B',
          description: 'יצירת מצגות PowerPoint',
          children: [
            {
              id: 'pptx-references',
              name: 'References',
              type: 'folder',
              color: '#8B5CF6',
              children: [
                {
                  id: 'pptx-ref-design-system',
                  name: 'design-system.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'pptx-ref-editing',
                  name: 'editing.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'pptx-ref-pitfalls',
                  name: 'pitfalls.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'pptx-ref-pptxgenjs',
                  name: 'pptxgenjs.md',
                  type: 'reference',
                  color: '#F59E0B'
                },
                {
                  id: 'pptx-ref-slide-types',
                  name: 'slide-types.md',
                  type: 'reference',
                  color: '#F59E0B'
                }
              ]
            }
          ]
        },
        {
          id: 'openclaw-doctor',
          name: 'openclaw-doctor',
          type: 'skill',
          color: '#EF4444',
          description: 'אבחון ותיקון בעיות OpenClaw'
        },
        {
          id: 'openclaw-install',
          name: 'openclaw-install',
          type: 'skill',
          color: '#06B6D4',
          description: 'התקנה והגדרת OpenClaw'
        }
      ]
    },
    {
      id: 'plugins',
      name: 'Plugins',
      type: 'folder',
      color: '#10B981',
      description: 'פלאגאינים של המערכת',
      children: [
        {
          id: 'plugin-default-skills',
          name: 'default-skills',
          type: 'plugin',
          color: '#10B981',
          description: 'פלאגין הסקילים הבסיסי'
        }
      ]
    },
    {
      id: 'browser',
      name: 'Browser',
      type: 'folder',
      color: '#EC4899',
      description: 'הרחבות דפדפן',
      children: [
        {
          id: 'browser-extension',
          name: 'browser_extension',
          type: 'folder',
          color: '#8B5CF6',
          children: [
            {
              id: 'error-capture',
              name: 'error_capture',
              type: 'tool',
              color: '#06B6D4',
              description: 'לכידת שגיאות מהדפדפן'
            }
          ]
        }
      ]
    }
  ]
};
